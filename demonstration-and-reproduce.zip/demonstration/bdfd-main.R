library(mise)
library(tictoc)
# mise()

# taskset -c 22-31 Rscript napkin-real-main.R 0 10000

suppressMessages(source('bdfd-data.R'))
suppressMessages(source('bdfd-vDML.R'))
suppressMessages(source('bdfd-DML.R'))

args = commandArgs(trailingOnly = TRUE)

computePerformance = function(OBS,answer,prediction){
  Xunique = unique(OBS$X)[order(unique(OBS$X))]
  idx = 1 
  proportion_X = rep(0,length(Xunique))
  for (xval in Xunique){
    proportion_X[idx] = nrow(subset(OBS,X==xval))/nrow(OBS)
    idx = idx + 1 
  }
  return(sum(abs(answer-prediction)*proportion_X))
}

computePerformanceAbsolute = function(OBS,answer,prediction){
  return(mean(abs(answer-prediction),na.rm=T))
}

ResultingPerformanceTable_Absolute = function(DMLanswer,vDMLanswer,answer,OBS){
  finalperformance = c()
  for (mismode in c(0,1,2)){
    performance_DML = computePerformanceAbsolute(OBS,answer,get(paste("DMLanswer.",mismode,sep="")))
    performance_vDML = computePerformanceAbsolute(OBS,answer,get(paste("vDMLanswer.",mismode,sep="")))
    myresult = c(performance_DML,performance_vDML)
    finalperformance = rbind(finalperformance,myresult)
  }
  tmp_mat = matrix(round(finalperformance,3),ncol=2)
  colnames(tmp_mat) = c('DML','vDML')
  rownames(tmp_mat) = c('(abs) mis0','(abs) mis1','(abs) mis2')
  
  winner_array = c()
  for (mismode in c(0,1,2)){
    winner_name = colnames(tmp_mat)[which.min(tmp_mat[(mismode+1),])]
    winner_array = c(winner_array,winner_name)
  }
  tmp_mat = cbind(tmp_mat,winner_array)
  colnames(tmp_mat)[ncol(tmp_mat)] = "Winner"
  
  return(tmp_mat)
}

ResultingPerformanceTable_Weight = function(DMLanswer,vDMLanswer,answer,OBS){
  finalperformance = c()
  for (mismode in c(0,1,2)){
    performance_DML = computePerformance(OBS,answer,get(paste("DMLanswer.",mismode,sep="")))
    performance_vDML = computePerformance(OBS,answer,get(paste("vDMLanswer.",mismode,sep="")))
    myresult = c(performance_DML,performance_vDML)
    finalperformance = rbind(finalperformance,myresult)
  }
  tmp_mat = matrix(round(finalperformance,3),ncol=2)
  colnames(tmp_mat) = c('DML','vDML')
  rownames(tmp_mat) = c('(weight) mis0','(weight) mis1','(weight) mis2')
  
  winner_array = c()
  for (mismode in c(0,1,2)){
    winner_name = colnames(tmp_mat)[which.min(tmp_mat[(mismode+1),])]
    winner_array = c(winner_array,winner_name)
  }
  tmp_mat = cbind(tmp_mat,winner_array)
  colnames(tmp_mat)[ncol(tmp_mat)] = "Winner"
  
  return(tmp_mat)
  # print(paste("Mismode:",mismode))
  # print(tmp_mat)
  
  # print(paste("Winner: ",colnames(tmp_mat)[which.min(tmp_mat)],sep=""))
}

# mismode = as.numeric(args[1])

N = as.numeric(args[1])
D = as.numeric(args[2])
seednum = as.numeric(args[3])
# seednum = sample(1:10000000,1)
print(c(N,D,seednum))
# seednum = 4536437


# seednum = 123
# mismode = 0
# N = 10000

Nintv = 1000000
tmp = dataGen(seednum,N,Nintv,D)
OBS = tmp[[1]]
INTV = tmp[[2]]

proportion_X = c(0,0); idx = 1
for (xval in c(0,1)){
  proportion_X[idx] = nrow(subset(OBS,X==xval))/nrow(OBS)
  idx = idx + 1 
}
proportion_X = round(proportion_X,4)

answer = c(0,0)
idx = 1
for (xval in c(0,1)){
  answer[idx] = mean(INTV[INTV$X.intv == xval,'Y.intv'])
  idx = idx + 1   
}

for (mismode in c(0,1,2)){
  tic(); vDMLanswer = vDMLEstimator(OBS,D,mismode,seednum); toc(); print('Done: vDMLanswer')  
  tic(); DMLanswer = DMLEstimator(OBS,D,mismode,seednum); toc(); print('Done: DMLanswer')  
  
  assign(paste("DMLanswer.",mismode,sep=""),DMLanswer)
  assign(paste("vDMLanswer.",mismode,sep=""),vDMLanswer)
}

DMLanswer = c(DMLanswer.0,DMLanswer.1,DMLanswer.2)
vDMLanswer = c(vDMLanswer.0,vDMLanswer.1,vDMLanswer.2)

# asBDanswer = asBDEstimator(OBS,mismode,seednum)

print("answer: Weighted")
tmp_mat = ResultingPerformanceTable_Weight(DMLanswer,vDMLanswer,answer,OBS)
print(tmp_mat)

print("answer: Absolute")
tmp_mat = ResultingPerformanceTable_Absolute(DMLanswer,vDMLanswer,answer,OBS)
print(tmp_mat)
