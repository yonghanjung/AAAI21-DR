source('RID_functions.R')
source('WERM_Heuristic.R')
source('DRModule.R')

vDMLEstimator = function(OBS,D,mismode,seednum){
  ####################################################
  # TrainModel 
  ####################################################
  TrainModel = function(DATA_Train, DATA_Eval, DATA, xfix, yfix, mismode){
    W = DATA_Train[,c(1:D)]
    X = DATA_Train[,(D+1)]
    Z = DATA_Train[,(D+2)]
    Y = DATA_Train[,(D+3)]
    
    IyTrain = (DATA_Train$Y == 1)*1
    Ztrain = DATA_Train$Z 
    Xtrain = DATA_Train$X 
    if (mismode == 1){
      IyTrain = distortVar(IyTrain,seednum)
    }
    if (mismode == 2){
      Xtrain = distortVar(Xtrain,seednum)
    }
    mylambda = rep(100/sqrt(nrow(DATA_Train)),nrow(DATA_Train))
    regvallist = seq(0,10,by=0.2)
    
    # Model for P(y | w,x)
    lambda.Y = mylambda
    model.y.WX = learnXG(inVar = data.matrix(data.frame(W = W, X = Xtrain)),labelval = IyTrain, regval = lambda.Y, binommode = 1)
    
    # Model for P(x | w)
    lambda.X = mylambda
    model.x.W = learnXG(inVar = data.matrix(data.frame(W=W)),labelval = Xtrain, regval = lambda.X, binommode = 1)
    
    return(list(model.y.WX, model.x.W))
  }
  
  Compute_UIF = function(DATA_Train, DATA_Eval, trainedlist, yfix, xfix){
    
    W = DATA_Eval[,c(1:D)]
    X = DATA_Eval[,(D+1)]
    Z = DATA_Eval[,(D+2)]
    Y = DATA_Eval[,(D+3)]
    
    Ix = (X == xfix)*1
    Iy = (Y == 1)*1
    
    model.y.WX = trainedlist[[1]]; model.x.W = trainedlist[[2]]
    ## Evaluate P(y | W,X), P(y|W,x)
    prob.y.WX = predict(model.y.WX,newdata=data.matrix(data.frame(W=W,X=X)),type='response')
    prob.y.Wx = predict(model.y.WX,newdata=data.matrix(data.frame(W=W, X=rep(xfix,nrow(DATA_Eval)))),type='response')
    if (mismode == 0){
      cvgrate = 4 
      myN = nrow(DATA_Train)*2
      prob.y.WX = fix_pred(prob.y.WX + rnorm(n= myN,  mean = myN^(-1/cvgrate), sd = myN^(-1/cvgrate)))
      prob.y.Wx = fix_pred(prob.y.Wx + rnorm(n= myN,  mean = myN^(-1/cvgrate), sd = myN^(-1/cvgrate)))
    }
    
    ## Evaluate P(X | W)
    pred.X.W = predict(model.x.W, newdata=data.matrix(data.frame(W=W)),type='response')
    prob.X.W = pred.X.W * X + (1-pred.X.W)*(1-X)
    
    
    UIF_M1 = (Ix*(Iy - prob.y.WX)/(prob.X.W)) + (prob.y.Wx) 
    return(UIF_M1)
  }
  
  Compute_Yx = function(DATA_Train, DATA_Eval, trainedlist, yfix, xfix){
    UIF = Compute_UIF(DATA_Train, DATA_Eval, trainedlist, yfix, xfix)
    return(mean(UIF,na.rm=T))
  }
  
  ConductDoubleML = function(numIter,DATA,xfix,yfix,mismode){
    YxList = rep(0,numIter)
    tmp = GoodSplit(DATA)
    DATA_Train = tmp[[1]]
    DATA_Eval = tmp[[2]]
    for (iteridx in 1:numIter){
      trainedlist1 = TrainModel(DATA_Train, DATA_Eval, DATA, xfix, yfix, mismode)
      trainedlist2 = TrainModel(DATA_Eval, DATA_Train, DATA, xfix, yfix, mismode)
      Yxval = mean(Compute_Yx(DATA_Train, DATA_Eval, trainedlist1, yfix, xfix),
                   Compute_Yx(DATA_Eval,DATA_Train, trainedlist2, yfix, xfix),na.rm=T)
      YxList[iteridx] = Yxval
    }
    return(mean(YxList,na.rm=T))
  }
  
  ####################################################
  # Main 
  ####################################################
  W = OBS[,c(1:D)]
  X = OBS[,(D+1)]
  Z = OBS[,(D+2)]
  Y = OBS[,(D+3)]
  
  DATA = OBS
  Ndata = nrow(DATA)
  
  tmp = GoodSplit(DATA)
  DATA_Train = tmp[[1]]
  DATA_Eval = tmp[[2]]
  
  yfix = 1 
  Yx.vDML = c(0,0)
  idx = 1 
  for (xfix in c(0,1)){
    # YxDR[idx] = ConductDoubleML(numIter=1,DATA=DATA,xfix=xfix,yfix=yfix,mismode=mismode)
    trainedlist1 = TrainModel(DATA_Train, DATA_Eval, DATA, xfix, yfix, mismode)
    trainedlist2 = TrainModel(DATA_Eval, DATA_Train , DATA, xfix, yfix, mismode)
    # trainedlist3 = TrainModel(DATA, DATA , DATA, xfix, yfix, mismode)
    myYx = mean(Compute_Yx(DATA_Train, DATA_Eval, trainedlist1, yfix, xfix),
                     Compute_Yx(DATA_Eval, DATA_Train , trainedlist2, yfix, xfix),
                     na.rm=T)
    # YxDR[idx] = mean(Compute_Yx(DATA, DATA, trainedlist3, yfix, xfix),
    #                  Compute_Yx(DATA, DATA , trainedlist3, yfix, xfix),
    #                  na.rm=T)
    Yx.vDML[idx] = max(myYx,0)
    Yx.vDML[idx] = min(myYx,1)
    idx = idx + 1 
  }
  return(Yx.vDML)
}




